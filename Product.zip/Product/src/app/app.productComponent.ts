import {Component,OnInit} from '@angular/core';
import {ProductService} from './app.productService';

@Component({
    selector:'add-prod',
    templateUrl:'add.product.html'
})

export class AddProduct implements OnInit{
    constructor(private prodservice:ProductService){}
    prod:any={};
    prodAll:any[];
    ngOnInit(){
        this.prodservice.getAllProduct().subscribe((data:any)=>this.prodAll=data);
    }
    addProduct():any{
        //alert(this.prod.prodId + " " + this.prod.prodName);
        this.prodservice.addProduct(this.prod).subscribe((data)=>console.log(data));
    }
}